import { useState, type ReactNode } from "react";

type IconName =
  | "home"
  | "book"
  | "note"
  | "star"
  | "pill"
  | "calendar"
  | "users"
  | "heart"
  | "clock"
  | "check"
  | "plus"
  | "chevron"
  | "phone"
  | "bell"
  | "lock"
  | "alert"
  | "cart"
  | "car"
  | "wallet"
  | "sparkle"
  | "gift"
  | "edit"
  | "stethoscope"
  | "close"
  | "userPlus"
  | "video";

function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9" />
        <path d="M9 20v-6h6v6" />
      </>
    ),
    book: (
      <>
        <path d="M4 4h5a3 3 0 0 1 3 3v13a3 3 0 0 0-3-3H4Z" />
        <path d="M20 4h-5a3 3 0 0 0-3 3v13a3 3 0 0 1 3-3h5Z" />
      </>
    ),
    note: (
      <>
        <path d="M5 3h14v18H5z" />
        <path d="M8 8h8M8 12h8M8 16h5" />
      </>
    ),
    star: <path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6-5.4-2.8-5.4 2.8 1-6-4.4-4.3 6.1-.9Z" />,
    pill: (
      <>
        <path d="M8.5 19.5a5 5 0 0 1-7-7l8-8a5 5 0 0 1 7 7Z" />
        <path d="m6 8 7 7" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18" />
      </>
    ),
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.8M16 3.2a4 4 0 0 1 0 7.6" />
      </>
    ),
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    plus: <path d="M12 5v14M5 12h14" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    phone: (
      <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7 12.8 12.8 0 0 0 .7 2.8 2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5 12.8 12.8 0 0 0 2.8.7 2 2 0 0 1 1.8 2.1Z" />
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    lock: (
      <>
        <rect x="4" y="10" width="16" height="11" rx="2" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </>
    ),
    alert: (
      <>
        <path d="M10.3 3.6 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    cart: (
      <>
        <circle cx="9" cy="20" r="1" />
        <circle cx="19" cy="20" r="1" />
        <path d="M3 4h2l2.5 11h11l2-8H6" />
      </>
    ),
    car: (
      <>
        <path d="m5 17-1 2v2M19 17l1 2v2M4 17h16l-2-7H6Z" />
        <path d="M7 17h.01M17 17h.01" />
      </>
    ),
    wallet: (
      <>
        <path d="M3 6h18v14H3z" />
        <path d="M3 6l14-3v3M16 12h5" />
      </>
    ),
    sparkle: (
      <>
        <path d="m12 3 1.3 3.7L17 8l-3.7 1.3L12 13l-1.3-3.7L7 8l3.7-1.3Z" />
        <path d="m18 14 .8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8Z" />
      </>
    ),
    gift: (
      <>
        <rect x="3" y="8" width="18" height="13" />
        <path d="M12 8v13M3 12h18" />
        <path d="M12 8H7.5A2.5 2.5 0 1 1 10 5.5ZM12 8h4.5A2.5 2.5 0 1 0 14 5.5Z" />
      </>
    ),
    edit: (
      <>
        <path d="M12 20h9" />
        <path d="m16.5 3.5 4 4L8 20l-5 1 1-5Z" />
      </>
    ),
    stethoscope: (
      <>
        <path d="M6 3v5a4 4 0 0 0 8 0V3M8 3H4M16 3h-4" />
        <path d="M10 17a5 5 0 0 0 10 0v-3" />
        <circle cx="20" cy="12" r="2" />
      </>
    ),
    close: <path d="m6 6 12 12M18 6 6 18" />,
    userPlus: (
      <>
        <path d="M15 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="8" cy="7" r="4" />
        <path d="M19 8v6M16 11h6" />
      </>
    ),
    video: (
      <>
        <rect x="2" y="5" width="15" height="14" rx="2" />
        <path d="m17 10 5-3v10l-5-3Z" />
      </>
    ),
  };
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

type Screen =
  | "home"
  | "admin"
  | "log"
  | "needs"
  | "notes"
  | "points"
  | "profile"
  | "family"
  | "emergency"
  | "medications"
  | "appointments"
  | "tasks"
  | "caregivers"
  | "patient-create";

type PatientId = "jose" | "elena" | "roberto";

function Button({
  children,
  onClick,
  variant = "primary",
  icon,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  icon?: IconName;
  className?: string;
}) {
  return (
    <button className={`btn btn-${variant} ${className}`} onClick={onClick}>
      {icon && <Icon name={icon} size={20} />}
      <span>{children}</span>
    </button>
  );
}

function IconButton({
  icon,
  label,
  onClick,
}: {
  icon: IconName;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button className="icon-button" aria-label={label} onClick={onClick}>
      <Icon name={icon} />
    </button>
  );
}

function FormField({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <label className="form-field">
      <span>{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function ActionSheet({
  title,
  subtitle,
  children,
  close,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  close: () => void;
}) {
  return (
    <div className="sheet-backdrop" onClick={close}>
      <section className="bottom-sheet action-sheet" onClick={(event) => event.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="sheet-title">
          <div>
            {subtitle && <span className="eyebrow">{subtitle}</span>}
            <h2>{title}</h2>
          </div>
          <IconButton icon="close" label="Cerrar" onClick={close} />
        </div>
        {children}
      </section>
    </div>
  );
}

function Avatar({
  person = "jose",
  size = "md",
}: {
  person?: "jose" | "maria" | "roberto" | "ana" | "luis";
  size?: "sm" | "md" | "lg" | "xl";
}) {
  if (person === "ana" || person === "luis") {
    return (
      <span className={`avatar initials avatar-${size} ${person}`}>
        {person === "ana" ? "AM" : "LR"}
      </span>
    );
  }
  return (
    <span className={`avatar illustrated avatar-${size} ${person}`}>
      <span className="hair" />
      <span className="face">
        <span className="eyes" />
        <span className="smile" />
      </span>
      {person === "jose" && <span className="glasses" />}
    </span>
  );
}

function TopBar({
  title,
  subtitle,
  back,
  onProfile,
  onPoints,
  points = true,
}: {
  title: string;
  subtitle?: string;
  back?: () => void;
  onProfile?: () => void;
  onPoints?: () => void;
  points?: boolean;
}) {
  return (
    <header className="topbar">
      <div className="topbar-left">
        {back && <IconButton icon="chevron" label="Volver" onClick={back} />}
        <div>
          <span className="eyebrow">{subtitle}</span>
          <strong className="page-title">{title}</strong>
        </div>
      </div>
      <div className="topbar-actions">
        {points && (
          <button className="points-chip" onClick={onPoints} aria-label="Abrir puntos">
            <Icon name="star" size={15} /> 840
          </button>
        )}
        {onProfile ? (
          <button className="avatar-button" onClick={onProfile} aria-label="Abrir perfil">
            <Avatar person="ana" size="sm" />
          </button>
        ) : (
          <Avatar person="ana" size="sm" />
        )}
      </div>
    </header>
  );
}

function BottomNav({ active, navigate }: { active: Screen; navigate: (s: Screen) => void }) {
  const tabs: { id: Screen; label: string; icon: IconName }[] = [
    { id: "home", label: "Inicio", icon: "home" },
    { id: "log", label: "Bitácora", icon: "book" },
    { id: "notes", label: "Notas", icon: "note" },
    { id: "points", label: "Puntos", icon: "star" },
  ];
  return (
    <nav className="bottom-nav">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`nav-item ${active === tab.id ? "active" : ""}`}
          onClick={() => navigate(tab.id)}
        >
          <Icon name={tab.icon} size={21} />
          <span>{tab.label}</span>
        </button>
      ))}
    </nav>
  );
}

function Home({
  navigate,
  notify,
  patient,
  selectPatient,
}: {
  navigate: (s: Screen) => void;
  notify: (message: string) => void;
  patient: PatientId;
  selectPatient: (patient: PatientId) => void;
}) {
  const [doneTasks, setDoneTasks] = useState<number[]>([]);
  const toggleTask = (index: number) => {
    setDoneTasks((current) =>
      current.includes(index) ? current.filter((task) => task !== index) : [...current, index],
    );
    notify("Tarea actualizada");
  };
  return (
    <div className="screen">
      <TopBar
        title={patient === "jose" ? "Don José" : patient === "elena" ? "Doña Elena" : "Don Roberto"}
        subtitle="Buenos días, Ana"
        onProfile={() => navigate("admin")}
        onPoints={() => navigate("points")}
      />
      <main className="content home-content">
        <section className="patient-switch" aria-label="Cambiar paciente">
          <button
            className={`patient-chip ${patient === "jose" ? "selected" : ""}`}
            onClick={() => {
              selectPatient("jose");
              navigate("profile");
            }}
          >
            <Avatar person="jose" size="sm" />
            <span>José</span>
          </button>
          <button
            className={`patient-chip ${patient === "elena" ? "selected" : ""}`}
            onClick={() => {
              selectPatient("elena");
              navigate("profile");
            }}
          >
            <Avatar person="maria" size="sm" />
            <span>Elena</span>
          </button>
          <button
            className={`patient-chip ${patient === "roberto" ? "selected" : ""}`}
            onClick={() => {
              selectPatient("roberto");
              navigate("profile");
            }}
          >
            <Avatar person="roberto" size="sm" />
            <span>Roberto</span>
          </button>
          <button
            className="add-patient"
            aria-label="Agregar paciente"
            onClick={() => navigate("patient-create")}
          >
            <Icon name="plus" size={18} />
          </button>
        </section>

        <section className="greeting">
          <div>
            <span className="eyebrow">MIÉRCOLES, 18 NOV 2026</span>
            <h1>¿Cómo estuvo hoy?</h1>
          </div>
          <span className="status-pill">
            <span className="status-dot" /> Todo en orden
          </span>
        </section>

        <section className="quick-grid">
          <button className="quick-card mint" onClick={() => navigate("log")}>
            <span className="quick-icon">
              <Icon name="book" />
            </span>
            <strong>Bitácora</strong>
            <small>3 registros hoy</small>
            <Icon name="chevron" size={18} />
          </button>
          <button className="quick-card yellow" onClick={() => navigate("medications")}>
            <span className="quick-icon">
              <Icon name="pill" />
            </span>
            <strong>Medicamentos</strong>
            <small>Próximo 14:00</small>
            <Icon name="chevron" size={18} />
          </button>
          <button className="quick-card peach" onClick={() => navigate("appointments")}>
            <span className="quick-icon">
              <Icon name="calendar" />
            </span>
            <strong>Citas</strong>
            <small>Jueves, 10:30</small>
            <Icon name="chevron" size={18} />
          </button>
          <button className="quick-card blue" onClick={() => navigate("family")}>
            <span className="quick-icon">
              <Icon name="users" />
            </span>
            <strong>Familia</strong>
            <small>2 novedades</small>
            <Icon name="chevron" size={18} />
          </button>
        </section>

        <section>
          <div className="section-heading">
            <h2>Próximas tareas</h2>
            <button className="text-button" onClick={() => navigate("tasks")}>
              Ver todas
            </button>
          </div>
          <div className="card task-list">
            <div className="task-row">
              <span className="time">12:30</span>
              <span className="task-icon pill">
                <Icon name="pill" size={18} />
              </span>
              <div>
                <strong>Losartán · 50 mg</strong>
                <small>Después de comer</small>
              </div>
              <button
                className={`check-button ${doneTasks.includes(0) ? "done" : ""}`}
                aria-label="Completar"
                onClick={() => toggleTask(0)}
              >
                <Icon name="check" size={17} />
              </button>
            </div>
            <div className="divider" />
            <div className="task-row">
              <span className="time">16:00</span>
              <span className="task-icon heart">
                <Icon name="heart" size={18} />
              </span>
              <div>
                <strong>Caminata suave</strong>
                <small>15 minutos</small>
              </div>
              <button
                className={`check-button ${doneTasks.includes(1) ? "done" : ""}`}
                aria-label="Completar"
                onClick={() => toggleTask(1)}
              >
                <Icon name="check" size={17} />
              </button>
            </div>
          </div>
        </section>

        <button className="need-summary" onClick={() => navigate("needs")}>
          <span className="need-avatars">
            <Avatar person="ana" size="sm" />
            <Avatar person="luis" size="sm" />
          </span>
          <span>
            <strong>2 necesidades abiertas</strong>
            <small>La familia puede apoyar</small>
          </span>
          <Icon name="chevron" size={18} />
        </button>
      </main>
      <button className="emergency-fab" onClick={() => navigate("emergency")}>
        <Icon name="phone" size={20} />
        <span>EMERGENCIA</span>
      </button>
    </div>
  );
}

const calendarMonths = [
  { label: "Octubre 2026", days: 31, offset: 3 },
  { label: "Noviembre 2026", days: 30, offset: 6 },
  { label: "Diciembre 2026", days: 31, offset: 1 },
];
function CalendarView({ openDay }: { openDay: (day: number) => void }) {
  const [monthIndex, setMonthIndex] = useState(1);
  const month = calendarMonths[monthIndex];
  const monthDays = Array.from({ length: month.days }, (_, index) => index + 1);
  return (
    <>
      <div className="week-strip">
        {["L 16", "M 17", "X 18", "J 19", "V 20"].map((day, i) => (
          <button
            key={day}
            className={`week-day ${i === 2 ? "today" : ""}`}
            onClick={() => openDay(16 + i)}
          >
            <small>{day.split(" ")[0]}</small>
            <strong>{day.split(" ")[1]}</strong>
            {i === 2 && <span />}
          </button>
        ))}
      </div>
      <div className="card calendar-card">
        <div className="calendar-title">
          <IconButton
            icon="chevron"
            label="Mes anterior"
            onClick={() => setMonthIndex((current) => Math.max(0, current - 1))}
          />
          <strong>{month.label}</strong>
          <IconButton
            icon="chevron"
            label="Mes siguiente"
            onClick={() => setMonthIndex((current) => Math.min(2, current + 1))}
          />
        </div>
        <div className="weekday-row">
          {["L", "M", "X", "J", "V", "S", "D"].map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
        <div className="month-grid">
          {Array.from({ length: month.offset }, (_, index) => (
            <span className="calendar-blank" key={`blank-${index}`} />
          ))}
          {monthDays.map((day) => {
            const complete =
              monthIndex === 1 && [2, 3, 4, 6, 9, 10, 11, 12, 13, 16, 17, 18].includes(day);
            const incident = monthIndex === 1 && [4, 12].includes(day);
            const appointment = monthIndex === 1 && [8, 19].includes(day);
            const support = monthIndex === 1 && [20, 26].includes(day);
            return (
              <button
                key={day}
                onClick={() => openDay(day)}
                className={`calendar-day ${complete ? "complete" : "empty"} ${monthIndex === 1 && day === 18 ? "selected" : ""}`}
              >
                <span>{day}</span>
                <small>
                  {monthIndex === 1 && [3, 9, 10, 16, 17, 18].includes(day)
                    ? "⌣"
                    : monthIndex === 1 && day === 12
                      ? "•︵•"
                      : ""}
                </small>
                {incident && <i className="incident-dot" />}
                {appointment && <i className="appointment-mark">+</i>}
                {support && <i className="support-mark" />}
              </button>
            );
          })}
        </div>
        <div className="legend">
          <span>
            <i className="legend-fill" /> Registro completo
          </span>
          <span>
            <i className="legend-dash" /> Sin registro
          </span>
          <span>
            <i className="legend-alert" /> Incidente
          </span>
          <span>
            <i className="legend-support" /> Apoyo familiar
          </span>
        </div>
      </div>
      <div className="month-summary">
        <h3>Resumen del mes</h3>
        <div className="summary-grid">
          <div>
            <strong>14</strong>
            <small>días registrados</small>
          </div>
          <div>
            <strong>☺</strong>
            <small>ánimo tranquilo</small>
          </div>
          <div>
            <strong>2</strong>
            <small>incidentes</small>
          </div>
          <div>
            <strong>2</strong>
            <small>citas</small>
          </div>
        </div>
        <div className="streak">
          <span style={{ width: "62%" }} />
          <small>Racha de 7 días</small>
        </div>
      </div>
    </>
  );
}

function NeedsView({ notify }: { notify: (message: string) => void }) {
  const [claimed, setClaimed] = useState(false);
  const [filter, setFilter] = useState("Todas");
  const [contribute, setContribute] = useState(false);
  const [amount, setAmount] = useState("500");
  const showAppointment = ["Todas", "Mías", "Citas", "Pendientes"].includes(filter);
  const showEconomic = ["Todas", "Económicas", "Pendientes"].includes(filter);
  return (
    <>
      <div className="filter-row">
        {["Todas", "Mías", "Económicas", "Citas", "Pendientes"].map((f) => (
          <button
            className={`filter-chip ${filter === f ? "active" : ""}`}
            key={f}
            onClick={() => setFilter(f)}
          >
            {f}
          </button>
        ))}
      </div>
      {showAppointment && (
        <article className="need-card urgent">
          <div className="need-card-head">
            <span className="type-icon">
              <Icon name="calendar" size={20} />
            </span>
            <div>
              <span className="priority high">Alta</span>
              <h3>Acompañar a cardiología</h3>
            </div>
            <Icon name="chevron" size={18} />
          </div>
          <p>Jueves 19 · 10:30 · Clínica Central</p>
          <div className="claimed-row">
            {claimed ? (
              <>
                <Avatar person="ana" size="sm" />
                <span>
                  <strong>Ana acompañará a Don José</strong>
                  <small>La familia ya fue notificada</small>
                </span>
              </>
            ) : (
              <>
                <span className="open-dot" />
                <span>
                  <strong>Pendiente</strong>
                  <small>Aún necesitamos ayuda</small>
                </span>
              </>
            )}
          </div>
          <Button
            variant={claimed ? "secondary" : "primary"}
            onClick={() => {
              setClaimed(!claimed);
              notify(
                claimed ? "Necesidad cerrada y registrada" : "La familia recibió tu confirmación",
              );
            }}
            icon={claimed ? "check" : "heart"}
          >
            {claimed ? "Ya lo hice" : "Yo puedo ayudar"}
          </Button>
        </article>
      )}
      {showEconomic && (
        <article className="need-card medium">
          <div className="need-card-head">
            <span className="type-icon peach">
              <Icon name="wallet" size={20} />
            </span>
            <div>
              <span className="priority mid">Media</span>
              <h3>Medicamentos del mes</h3>
            </div>
            <Icon name="chevron" size={18} />
          </div>
          <p>Fecha límite · 24 de noviembre de 2026</p>
          <div className="progress-copy">
            <strong>$1,200 de $2,000</strong>
            <span>60%</span>
          </div>
          <div className="progress">
            <span style={{ width: "60%" }} />
          </div>
          <div className="contributors">
            <Avatar person="luis" size="sm" />
            <Avatar person="ana" size="sm" />
            <span>Luis, Ana y 1 más aportaron</span>
          </div>
          <Button variant="secondary" icon="wallet" onClick={() => setContribute(true)}>
            Puedo aportar
          </Button>
        </article>
      )}
      {!showAppointment && !showEconomic && (
        <div className="covered">
          <span className="covered-art">
            <Icon name="check" />
          </span>
          <div>
            <strong>Todo cubierto por hoy</strong>
            <small>No hay resultados en este filtro.</small>
          </div>
        </div>
      )}
      <div className="covered">
        <span className="covered-art">
          <Icon name="check" />
        </span>
        <div>
          <strong>Lo demás está cubierto</strong>
          <small>Gracias por coordinar a la familia</small>
        </div>
      </div>
      {contribute && (
        <ActionSheet
          title="Realizar aportación"
          subtitle="APOYO ECONÓMICO"
          close={() => setContribute(false)}
        >
          <div className="sheet-form">
            <FormField label="Monto a aportar" type="number" value={amount} onChange={setAmount} />
            <div className="quick-amounts">
              {["200", "500", "1000"].map((value) => (
                <button key={value} onClick={() => setAmount(value)}>
                  ${value}
                </button>
              ))}
            </div>
            <Button
              icon="wallet"
              onClick={() => {
                setContribute(false);
                notify(`Aportación de $${amount} registrada`);
              }}
            >
              Confirmar aportación
            </Button>
          </div>
        </ActionSheet>
      )}
    </>
  );
}

function Logbook({
  initialSegment = "calendar",
  navigate,
  notify,
}: {
  initialSegment?: "calendar" | "needs";
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
}) {
  const [segment, setSegment] = useState<"calendar" | "needs">(initialSegment);
  const [sheet, setSheet] = useState(false);
  const [sheetMode, setSheetMode] = useState<"timeline" | "entry" | "need">("timeline");
  const [selectedDay, setSelectedDay] = useState(18);
  const [category, setCategory] = useState("Alimentación");
  const [entryNote, setEntryNote] = useState("");
  const [needTitle, setNeedTitle] = useState("");
  const [mood, setMood] = useState("☺");
  const [urgency, setUrgency] = useState("Media");
  const [entryTime, setEntryTime] = useState("12:30");
  const [needDate, setNeedDate] = useState("2026-11-24");
  const [entries, setEntries] = useState([
    {
      time: "08:15",
      category: "Alimentación",
      note: "Avena, fruta y té. Buen apetito.",
      mood: "☺",
    },
    {
      time: "09:00",
      category: "Medicamento",
      note: "Losartán · 50 mg",
      mood: "☺",
    },
    {
      time: "11:40",
      category: "Ánimo",
      note: "Conversó con Luis por teléfono.",
      mood: "🙂",
    },
  ]);
  const openTimeline = (day: number) => {
    setSelectedDay(day);
    setSheetMode("timeline");
    setSheet(true);
  };
  const openCreate = (mode: "entry" | "need") => {
    setSheetMode(mode);
    setSheet(true);
  };
  return (
    <div className="screen">
      <TopBar
        title="Bitácora"
        subtitle="DON JOSÉ"
        onProfile={() => navigate("admin")}
        onPoints={() => navigate("points")}
      />
      <main className="content log-content">
        <div className="segment">
          <button
            className={segment === "calendar" ? "active" : ""}
            onClick={() => setSegment("calendar")}
          >
            Calendario
          </button>
          <button
            className={segment === "needs" ? "active" : ""}
            onClick={() => setSegment("needs")}
          >
            Necesidades <span>2</span>
          </button>
        </div>
        {segment === "calendar" ? (
          <CalendarView openDay={openTimeline} />
        ) : (
          <NeedsView notify={notify} />
        )}
      </main>
      <Button
        className="floating-action"
        icon="plus"
        onClick={() => openCreate(segment === "calendar" ? "entry" : "need")}
      >
        {segment === "calendar" ? "Nueva entrada" : "Pedir apoyo"}
      </Button>
      {sheet && sheetMode === "timeline" && (
        <ActionSheet
          title={`${selectedDay} de noviembre de 2026`}
          subtitle="BITÁCORA DEL DÍA"
          close={() => setSheet(false)}
        >
          <div className="timeline">
            {entries.map((entry, index) => (
              <div className="timeline-item" key={`${entry.time}-${index}`}>
                <span className="timeline-time">{entry.time}</span>
                <span
                  className={`timeline-icon ${
                    entry.category === "Medicamento"
                      ? "meds"
                      : entry.category === "Ánimo"
                        ? "mood"
                        : "food"
                  }`}
                >
                  {entry.category === "Medicamento" ? (
                    <Icon name="pill" size={17} />
                  ) : entry.category === "Ánimo" ? (
                    entry.mood
                  ) : (
                    "☕"
                  )}
                </span>
                <div>
                  <strong>{entry.category}</strong>
                  <p>{entry.note}</p>
                  <small>Registró Ana · {entry.mood}</small>
                </div>
              </div>
            ))}
          </div>
          <Button icon="plus" onClick={() => setSheetMode("entry")}>
            Agregar otra entrada
          </Button>
        </ActionSheet>
      )}
      {sheet && sheetMode === "entry" && (
        <ActionSheet title="Nueva entrada" subtitle="BITÁCORA" close={() => setSheet(false)}>
          <div className="sheet-form">
            <label className="form-field">
              <span>Categoría</span>
              <select value={category} onChange={(event) => setCategory(event.target.value)}>
                {["Alimentación", "Medicamento", "Ánimo", "Sueño", "Higiene", "Incidente"].map(
                  (item) => (
                    <option key={item}>{item}</option>
                  ),
                )}
              </select>
            </label>
            <FormField label="Hora" type="time" value={entryTime} onChange={setEntryTime} />
            <FormField
              label="Nota breve"
              value={entryNote}
              onChange={setEntryNote}
              placeholder="¿Qué ocurrió?"
            />
            <div className="mood-picker">
              <span>Estado de ánimo</span>
              <div>
                {["☺", "🙂", "•‿•", "•︵•"].map((item) => (
                  <button
                    className={mood === item ? "selected" : ""}
                    key={item}
                    onClick={() => setMood(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            <label className="toggle-row">
              <span>
                <strong>Importante para la familia</strong>
                <small>Se enviará una notificación</small>
              </span>
              <input type="checkbox" />
            </label>
            <Button
              icon="check"
              onClick={() => {
                if (!entryNote.trim()) {
                  notify("Escribe una nota antes de guardar");
                  return;
                }
                setEntries((current) =>
                  [...current, { time: entryTime, category, note: entryNote.trim(), mood }].sort(
                    (a, b) => a.time.localeCompare(b.time),
                  ),
                );
                setSheetMode("timeline");
                setEntryNote("");
                notify(`${category} guardado en la bitácora`);
              }}
            >
              Guardar entrada
            </Button>
          </div>
        </ActionSheet>
      )}
      {sheet && sheetMode === "need" && (
        <ActionSheet title="Pedir apoyo" subtitle="NUEVA NECESIDAD" close={() => setSheet(false)}>
          <div className="sheet-form">
            <label className="form-field">
              <span>Tipo de apoyo</span>
              <select>
                {[
                  "Acompañar a una cita",
                  "Apoyo económico",
                  "Comprar o llevar algo",
                  "Traslado",
                  "Visita o compañía",
                  "Otro",
                ].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
            <FormField
              label="¿Qué se necesita?"
              value={needTitle}
              onChange={setNeedTitle}
              placeholder="Describe el apoyo"
            />
            <FormField label="Fecha" type="date" value={needDate} onChange={setNeedDate} />
            <div className="priority-picker">
              <span>Urgencia</span>
              {[
                ["Informativa", "info"],
                ["Media", "mid"],
                ["Alta", "high"],
              ].map(([label, tone]) => (
                <button
                  key={label}
                  className={`priority ${tone} ${urgency === label ? "selected" : ""}`}
                  onClick={() => setUrgency(label)}
                >
                  {label}
                </button>
              ))}
            </div>
            <Button
              icon="bell"
              onClick={() => {
                setSheet(false);
                setNeedTitle("");
                notify("Necesidad publicada y familia notificada");
              }}
            >
              Publicar necesidad
            </Button>
          </div>
        </ActionSheet>
      )}
    </div>
  );
}

function Notes({
  navigate,
  notify,
}: {
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
}) {
  const [filter, setFilter] = useState("Todas");
  const [newNote, setNewNote] = useState(false);
  const [noteTitle, setNoteTitle] = useState("");
  const [noteDetail, setNoteDetail] = useState("");
  const [selectedNote, setSelectedNote] = useState("");
  return (
    <div className="screen">
      <TopBar
        title="Notas importantes"
        subtitle="INFORMACIÓN QUE CUIDA"
        onProfile={() => navigate("admin")}
        onPoints={() => navigate("points")}
      />
      <main className="content">
        <div className="notes-intro">
          <span className="notes-icon">
            <Icon name="lock" />
          </span>
          <div>
            <h2>Información sensible</h2>
            <p>Visible según los permisos de cada familiar.</p>
          </div>
        </div>
        <div className="filter-row">
          {["Todas", "Alta", "Media", "Informativa"].map((f) => (
            <button
              className={`filter-chip ${filter === f ? "active" : ""}`}
              key={f}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        {(filter === "Todas" || filter === "Alta") && (
          <button
            className="note-card high-border"
            onClick={() => setSelectedNote("Alergia a la penicilina")}
          >
            <div className="note-head">
              <span className="priority high">Alta</span>
              <Icon name="lock" size={17} />
            </div>
            <h3>Alergia a la penicilina</h3>
            <p>Ha presentado reacción severa. Informar siempre antes de cualquier tratamiento.</p>
            <div className="note-meta">
              <span>Actualizada hace 2 días</span>
              <span>Solo administradores</span>
            </div>
          </button>
        )}
        {(filter === "Todas" || filter === "Media") && (
          <button
            className="note-card mid-border"
            onClick={() => setSelectedNote("Rutina para dormir")}
          >
            <div className="note-head">
              <span className="priority mid">Media</span>
              <Icon name="users" size={17} />
            </div>
            <h3>Rutina para dormir</h3>
            <p>Le ayuda escuchar boleros suaves y dejar una luz tenue encendida.</p>
            <div className="note-meta">
              <span>Actualizada por Ana</span>
              <span>Toda la familia</span>
            </div>
          </button>
        )}
        {(filter === "Todas" || filter === "Informativa") && (
          <button
            className="note-card info-border"
            onClick={() => setSelectedNote("Le gusta hablar del jardín")}
          >
            <div className="note-head">
              <span className="priority info">Informativa</span>
              <Icon name="users" size={17} />
            </div>
            <h3>Le gusta hablar del jardín</h3>
            <p>Preguntarle por sus rosales suele animarlo durante las tardes.</p>
            <div className="note-meta">
              <span>Hace 1 semana</span>
              <span>Toda la familia</span>
            </div>
          </button>
        )}
      </main>
      <Button className="floating-action" icon="plus" onClick={() => setNewNote(true)}>
        Nueva nota
      </Button>
      {newNote && (
        <ActionSheet
          title="Nueva nota importante"
          subtitle="INFORMACIÓN SENSIBLE"
          close={() => setNewNote(false)}
        >
          <div className="sheet-form">
            <FormField
              label="Título"
              value={noteTitle}
              onChange={setNoteTitle}
              placeholder="Ej. Rutina de descanso"
            />
            <FormField
              label="Detalle"
              value={noteDetail}
              onChange={setNoteDetail}
              placeholder="Información para la familia"
            />
            <label className="form-field">
              <span>Prioridad</span>
              <select>
                <option>Alta</option>
                <option>Media</option>
                <option>Informativa</option>
              </select>
            </label>
            <label className="toggle-row">
              <span>
                <strong>Nota sensible</strong>
                <small>Solo administradores</small>
              </span>
              <input type="checkbox" />
            </label>
            <Button
              icon="lock"
              onClick={() => {
                setNewNote(false);
                setNoteTitle("");
                setNoteDetail("");
                notify("Nota guardada con sus permisos");
              }}
            >
              Guardar nota
            </Button>
          </div>
        </ActionSheet>
      )}
      {selectedNote && (
        <ActionSheet
          title={selectedNote}
          subtitle="DETALLE DE LA NOTA"
          close={() => setSelectedNote("")}
        >
          <div className="sheet-form">
            <p className="sheet-description">
              Esta información está compartida con los usuarios autorizados y puede actualizarse
              cuando sea necesario.
            </p>
            <Button
              icon="edit"
              onClick={() => {
                setSelectedNote("");
                setNewNote(true);
                setNoteTitle(selectedNote);
              }}
            >
              Editar nota
            </Button>
          </div>
        </ActionSheet>
      )}
    </div>
  );
}

function Points({
  navigate,
  notify,
}: {
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
}) {
  const [redeem, setRedeem] = useState(false);
  const [redeemCost, setRedeemCost] = useState(300);
  const [balance, setBalance] = useState(840);
  const [pointsSheet, setPointsSheet] = useState<"earn" | "catalog" | null>(null);
  return (
    <div className="screen">
      <TopBar
        title="Puntos"
        subtitle="TU CONSTANCIA CUENTA"
        points={false}
        onProfile={() => navigate("admin")}
      />
      <main className="content">
        <section className="points-hero">
          <span className="eyebrow">SALDO DISPONIBLE</span>
          <div>
            <Icon name="star" size={28} />
            <strong>{balance}</strong>
            <small>puntos</small>
          </div>
          <p>Gracias por cuidar con constancia.</p>
          <div className="points-actions">
            <Button icon="sparkle" onClick={() => setPointsSheet("earn")}>
              Ganar puntos
            </Button>
            <Button variant="secondary" icon="gift" onClick={() => setPointsSheet("catalog")}>
              Canjear
            </Button>
          </div>
        </section>
        <section>
          <div className="section-heading">
            <h2>Reto de la semana</h2>
            <span className="reward">+80 pts</span>
          </div>
          <div className="card challenge">
            <div className="challenge-icon">
              <Icon name="book" />
            </div>
            <div>
              <strong>Bitácora al día</strong>
              <p>Registra 7 días seguidos</p>
              <div className="progress">
                <span style={{ width: "71%" }} />
              </div>
              <small>5 de 7 días</small>
            </div>
          </div>
        </section>
        <section>
          <div className="section-heading">
            <h2>Recompensas</h2>
            <button className="text-button" onClick={() => setPointsSheet("catalog")}>
              Ver todas
            </button>
          </div>
          <article className="reward-card">
            <span className="reward-icon mint">
              <Icon name="sparkle" />
            </span>
            <div>
              <strong>Resumen semanal con IA</strong>
              <p>Una lectura clara para toda la familia.</p>
              <span className="cost">
                <Icon name="star" size={14} /> 300
              </span>
            </div>
            <Button
              variant="secondary"
              onClick={() => {
                setRedeemCost(300);
                setRedeem(true);
              }}
            >
              Canjear
            </Button>
          </article>
          <article className="reward-card">
            <span className="reward-icon yellow">
              <Icon name="note" />
            </span>
            <div>
              <strong>Reporte PDF médico</strong>
              <p>Bitácora lista para tu próxima cita.</p>
              <span className="cost">
                <Icon name="star" size={14} /> 500
              </span>
            </div>
            <Button
              variant="secondary"
              onClick={() => {
                setRedeemCost(500);
                setRedeem(true);
              }}
            >
              Canjear
            </Button>
          </article>
        </section>
        <div className="free-note">
          <Icon name="heart" size={19} />
          <span>
            <strong>Lo esencial siempre es gratis</strong>
            <small>Emergencias, avisos y bitácora básica.</small>
          </span>
        </div>
      </main>
      {redeem && (
        <div className="sheet-backdrop">
          <section className="confirm-modal">
            <span className="confirm-icon">
              <Icon name="sparkle" size={30} />
            </span>
            <h2>¿Canjear {redeemCost} puntos?</h2>
            <p>
              Activarás {redeemCost === 300 ? "el resumen semanal con IA" : "el reporte PDF médico"}
              .
            </p>
            <Button
              onClick={() => {
                if (balance >= redeemCost) {
                  setBalance((current) => current - redeemCost);
                  notify("Recompensa activada y saldo actualizado");
                } else {
                  notify("No tienes puntos suficientes");
                }
                setRedeem(false);
              }}
            >
              Confirmar canje
            </Button>
            <Button variant="ghost" onClick={() => setRedeem(false)}>
              Ahora no
            </Button>
          </section>
        </div>
      )}
      {pointsSheet && (
        <ActionSheet
          title={pointsSheet === "earn" ? "Ganar puntos" : "Catálogo de recompensas"}
          subtitle={pointsSheet === "earn" ? "RETOS Y CONSTANCIA" : "BENEFICIOS"}
          close={() => setPointsSheet(null)}
        >
          <div className="option-list">
            {(pointsSheet === "earn"
              ? [
                  ["Bitácora diaria", "+20 puntos por día"],
                  ["Racha de 7 días", "+80 puntos"],
                  ["Cubrir una necesidad", "+40 puntos"],
                  ["Invitar a un familiar", "+100 puntos"],
                ]
              : [
                  ["Resumen semanal con IA", "300 puntos"],
                  ["Reporte PDF médico", "500 puntos"],
                  ["Perfil de paciente adicional", "700 puntos"],
                  ["Almacenamiento ampliado", "900 puntos"],
                ]
            ).map(([title, detail]) => (
              <button key={title} onClick={() => notify(`${title}: opción seleccionada`)}>
                <span>
                  <strong>{title}</strong>
                  <small>{detail}</small>
                </span>
                <Icon name="chevron" size={18} />
              </button>
            ))}
          </div>
        </ActionSheet>
      )}
    </div>
  );
}

const patientProfiles = {
  jose: {
    name: "José Ramírez",
    short: "Don José",
    age: 78,
    avatar: "jose" as const,
    schedule: [
      "08:00  Desayuno",
      "09:00  Losartán · 50 mg",
      "12:30  Comida",
      "16:00  Caminata suave",
    ],
    allergies: "Penicilina",
    conditions: "Hipertensión, diabetes tipo 2",
    blood: "O+",
    doctor: "Dra. Laura Méndez",
    specialty: "Medicina interna",
    phone: "+525512345678",
    phoneLabel: "55 1234 5678",
  },
  elena: {
    name: "Elena Torres",
    short: "Doña Elena",
    age: 82,
    avatar: "maria" as const,
    schedule: [
      "08:30  Levotiroxina · 50 mcg",
      "09:00  Desayuno",
      "13:00  Ejercicios de movilidad",
      "20:00  Calcio",
    ],
    allergies: "Ninguna conocida",
    conditions: "Artritis, osteoporosis",
    blood: "A+",
    doctor: "Dr. Jorge Salas",
    specialty: "Geriatría",
    phone: "+525598765432",
    phoneLabel: "55 9876 5432",
  },
  roberto: {
    name: "Roberto Díaz",
    short: "Don Roberto",
    age: 74,
    avatar: "roberto" as const,
    schedule: [
      "07:30  Presión arterial",
      "08:00  Desayuno",
      "10:00  Caminata",
      "19:30  Enalapril · 10 mg",
    ],
    allergies: "Sulfas",
    conditions: "Hipertensión",
    blood: "B+",
    doctor: "Dra. Sofía Luna",
    specialty: "Medicina familiar",
    phone: "+525544445555",
    phoneLabel: "55 4444 5555",
  },
};

function Profile({
  back,
  navigate,
  notify,
  patient,
}: {
  back: () => void;
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
  patient: PatientId;
}) {
  const [completed, setCompleted] = useState([0, 1]);
  const profile = patientProfiles[patient];
  return (
    <div className="screen">
      <TopBar title="Perfil del paciente" back={back} points={false} />
      <main className="content profile-content">
        <section className="profile-hero">
          <Avatar person={profile.avatar} size="xl" />
          <div>
            <h1>{profile.name}</h1>
            <p>
              {profile.age} años · {profile.short}
            </p>
            <button className="text-button" onClick={() => navigate("patient-create")}>
              <Icon name="edit" size={15} /> Cambiar avatar
            </button>
          </div>
        </section>
        <div className="profile-actions">
          <Button variant="secondary" icon="edit" onClick={() => navigate("patient-create")}>
            Editar
          </Button>
          <Button icon="plus" onClick={() => navigate("tasks")}>
            Tareas nuevas
          </Button>
        </div>
        <section>
          <div className="section-heading">
            <h2>Horarios de hoy</h2>
            <span className="status-pill">{completed.length} de 4</span>
          </div>
          <div className="card schedule">
            {profile.schedule.map((item, i) => (
              <button
                className="schedule-row"
                key={item}
                onClick={() =>
                  setCompleted((current) =>
                    current.includes(i) ? current.filter((value) => value !== i) : [...current, i],
                  )
                }
              >
                <span className={`schedule-check ${completed.includes(i) ? "done" : ""}`}>
                  <Icon name="check" size={15} />
                </span>
                <span>{item}</span>
              </button>
            ))}
          </div>
        </section>
        <section className="important-card">
          <div className="section-heading">
            <h2>Datos importantes</h2>
            <Icon name="alert" size={20} />
          </div>
          <dl>
            <div>
              <dt>Alergias</dt>
              <dd>{profile.allergies}</dd>
            </div>
            <div>
              <dt>Condiciones</dt>
              <dd>{profile.conditions}</dd>
            </div>
            <div>
              <dt>Tipo de sangre</dt>
              <dd>{profile.blood}</dd>
            </div>
          </dl>
        </section>
        <section className="card doctor-card">
          <span className="doctor-icon">
            <Icon name="stethoscope" />
          </span>
          <div>
            <small>MÉDICO DE CABECERA</small>
            <h3>{profile.doctor}</h3>
            <p>
              {profile.specialty} · {profile.phoneLabel}
            </p>
            <div>
              <Button
                variant="secondary"
                icon="phone"
                onClick={() => {
                  window.location.href = `tel:${profile.phone}`;
                }}
              >
                Llamar
              </Button>
              <Button
                variant="ghost"
                icon="bell"
                onClick={() => notify(`${profile.doctor} fue notificado`)}
              >
                Notificar
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Admin({
  back,
  navigate,
  notify,
}: {
  back: () => void;
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
}) {
  return (
    <div className="screen">
      <TopBar title="Mi perfil" subtitle="ADMINISTRADORA PRINCIPAL" back={back} points={false} />
      <main className="content">
        <section className="admin-hero">
          <Avatar person="ana" size="xl" />
          <div>
            <span className="role-badge">Admin</span>
            <h1>Ana Martínez</h1>
            <p>Cuidadora principal · 3 pacientes asignados</p>
          </div>
        </section>
        <div className="admin-stats">
          <div>
            <strong>3</strong>
            <small>pacientes</small>
          </div>
          <div>
            <strong>4</strong>
            <small>familiares</small>
          </div>
          <div>
            <strong>12</strong>
            <small>días de racha</small>
          </div>
        </div>
        <section>
          <div className="section-heading">
            <h2>Administración</h2>
          </div>
          <div className="admin-menu">
            <button onClick={() => navigate("patient-create")}>
              <span className="type-icon">
                <Icon name="users" size={20} />
              </span>
              <span>
                <strong>Pacientes</strong>
                <small>Perfiles, datos médicos y accesos</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
            <button onClick={() => navigate("caregivers")}>
              <span className="type-icon peach">
                <Icon name="userPlus" size={20} />
              </span>
              <span>
                <strong>Cuidadores y familia</strong>
                <small>Roles, permisos e invitaciones</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
            <button onClick={() => navigate("points")}>
              <span className="type-icon">
                <Icon name="star" size={20} />
              </span>
              <span>
                <strong>Plan y puntos</strong>
                <small>Saldo, recompensas y suscripción</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
          </div>
        </section>
        <section>
          <div className="section-heading">
            <h2>Preferencias</h2>
          </div>
          <label className="toggle-row">
            <span>
              <strong>Alertas familiares</strong>
              <small>Avisos de necesidades e incidentes</small>
            </span>
            <input
              type="checkbox"
              defaultChecked
              onChange={() => notify("Preferencia actualizada")}
            />
          </label>
          <label className="toggle-row">
            <span>
              <strong>Resumen diario</strong>
              <small>Recibirlo cada noche</small>
            </span>
            <input
              type="checkbox"
              defaultChecked
              onChange={() => notify("Preferencia actualizada")}
            />
          </label>
        </section>
        <Button
          variant="secondary"
          icon="edit"
          onClick={() => notify("Datos de Ana listos para editar")}
        >
          Editar mis datos
        </Button>
      </main>
    </div>
  );
}

function Family({ back, navigate }: { back: () => void; navigate: (screen: Screen) => void }) {
  return (
    <div className="screen">
      <TopBar
        title="Familia"
        subtitle="TODOS CERCA"
        back={back}
        points={false}
        onProfile={() => navigate("admin")}
      />
      <main className="content">
        <section className="daily-summary">
          <div className="summary-avatar">
            <Avatar person="jose" size="lg" />
            <span>☺</span>
          </div>
          <div>
            <span className="eyebrow">RESUMEN DE HOY</span>
            <h2>Un día tranquilo</h2>
            <p>Don José comió bien, tomó sus medicamentos y estuvo de buen ánimo.</p>
          </div>
        </section>
        <div className="family-stats">
          <div>
            <Icon name="pill" />
            <strong>2 de 3</strong>
            <small>medicamentos</small>
          </div>
          <div>
            <Icon name="heart" />
            <strong>Tranquilo</strong>
            <small>ánimo</small>
          </div>
          <div>
            <Icon name="alert" />
            <strong>0</strong>
            <small>incidentes</small>
          </div>
        </div>
        <button className="need-summary family-need" onClick={() => navigate("needs")}>
          <span className="need-count">2</span>
          <span>
            <strong>Necesidades abiertas</strong>
            <small>Tu ayuda puede hacer la diferencia</small>
          </span>
          <Icon name="chevron" size={18} />
        </button>
        <section>
          <div className="section-heading">
            <h2>Novedades</h2>
            <button className="text-button" onClick={() => navigate("log")}>
              Ver bitácora
            </button>
          </div>
          <button className="feed-item" onClick={() => navigate("log")}>
            <Avatar person="ana" size="sm" />
            <div>
              <p>
                <strong>Ana</strong> registró el desayuno y los medicamentos.
              </p>
              <small>Hace 2 horas</small>
            </div>
            <span className="feed-icon">
              <Icon name="check" size={17} />
            </span>
          </button>
          <button className="feed-item" onClick={() => navigate("needs")}>
            <Avatar person="luis" size="sm" />
            <div>
              <p>
                <strong>Luis</strong> aportó $500 para los medicamentos del mes.
              </p>
              <small>Hace 4 horas</small>
            </div>
            <span className="feed-icon peach">
              <Icon name="wallet" size={17} />
            </span>
          </button>
        </section>
        <Button variant="secondary" icon="userPlus" onClick={() => navigate("caregivers")}>
          Agregar nuevo cuidador
        </Button>
      </main>
    </div>
  );
}

function Emergency({ back, notify }: { back: () => void; notify: (message: string) => void }) {
  return (
    <div className="screen emergency-screen">
      <header className="emergency-top">
        <IconButton icon="close" label="Cerrar" onClick={back} />
        <strong>Emergencia</strong>
        <span />
      </header>
      <main className="content">
        <section className="emergency-call">
          <span className="emergency-pulse">
            <Icon name="phone" size={34} />
          </span>
          <h1>¿Necesitas ayuda inmediata?</h1>
          <p>Llama a emergencias y mantén esta información a la mano.</p>
          <Button
            variant="danger"
            icon="phone"
            onClick={() => {
              window.location.href = "tel:911";
            }}
          >
            Llamar al 911
          </Button>
        </section>
        <section className="critical-card">
          <div className="section-heading">
            <h2>Datos médicos críticos</h2>
            <Icon name="alert" />
          </div>
          <div>
            <span>Alergia severa</span>
            <strong>Penicilina</strong>
          </div>
          <div>
            <span>Medicamentos</span>
            <strong>Losartán · Metformina</strong>
          </div>
          <div>
            <span>Tipo de sangre</span>
            <strong>O positivo</strong>
          </div>
        </section>
        <section>
          <h2 className="section-title">Contactos prioritarios</h2>
          <div className="card contacts">
            <div>
              <Avatar person="ana" size="sm" />
              <span>
                <strong>Ana Martínez</strong>
                <small>Cuidadora principal</small>
              </span>
              <IconButton
                icon="phone"
                label="Llamar a Ana"
                onClick={() => {
                  window.location.href = "tel:+525511112222";
                }}
              />
            </div>
            <div className="divider" />
            <div>
              <Avatar person="luis" size="sm" />
              <span>
                <strong>Luis Ramírez</strong>
                <small>Hijo</small>
              </span>
              <IconButton
                icon="phone"
                label="Llamar a Luis"
                onClick={() => {
                  window.location.href = "tel:+525533334444";
                }}
              />
            </div>
            <div className="divider" />
            <div>
              <span className="doctor-contact">
                <Icon name="stethoscope" size={20} />
              </span>
              <span>
                <strong>Dra. Laura Méndez</strong>
                <small>Médico de cabecera · 55 1234 5678</small>
              </span>
              <IconButton
                icon="phone"
                label="Llamar a la doctora"
                onClick={() => {
                  window.location.href = "tel:+525512345678";
                }}
              />
            </div>
          </div>
        </section>
        <Button
          variant="primary"
          icon="bell"
          onClick={() => notify("Alerta enviada a toda la familia")}
        >
          Avisar a toda la familia
        </Button>
        <p className="emergency-note">
          <Icon name="heart" size={16} /> La ayuda de emergencia siempre es gratuita.
        </p>
      </main>
    </div>
  );
}

type UtilityKind = "medications" | "appointments" | "tasks" | "caregivers" | "patient-create";

const utilityContent: Record<
  UtilityKind,
  {
    title: string;
    subtitle: string;
    icon: IconName;
    intro: string;
    items: { title: string; detail: string; meta: string; done?: boolean }[];
    action: string;
  }
> = {
  medications: {
    title: "Medicamentos",
    subtitle: "HOY · DON JOSÉ",
    icon: "pill",
    intro: "Control claro de las tomas de hoy",
    items: [
      {
        title: "Losartán · 50 mg",
        detail: "09:00 · Después del desayuno",
        meta: "Tomado por Ana",
        done: true,
      },
      { title: "Metformina · 850 mg", detail: "14:00 · Después de comer", meta: "Próxima toma" },
      { title: "Atorvastatina · 20 mg", detail: "21:00 · Antes de dormir", meta: "Programado" },
    ],
    action: "Agregar medicamento",
  },
  appointments: {
    title: "Citas",
    subtitle: "PRÓXIMAS VISITAS",
    icon: "calendar",
    intro: "La familia ya conoce estas citas",
    items: [
      {
        title: "Cardiología",
        detail: "Jueves 19 · 10:30 · Clínica Central",
        meta: "Ana acompañará a Don José",
        done: true,
      },
      {
        title: "Laboratorio",
        detail: "Martes 24 · 08:00 · En ayuno",
        meta: "Falta confirmar traslado",
      },
    ],
    action: "Agregar cita",
  },
  tasks: {
    title: "Tareas",
    subtitle: "RUTINA DE HOY",
    icon: "check",
    intro: "3 de 5 tareas completadas",
    items: [
      { title: "Desayuno", detail: "08:00 · Avena, fruta y té", meta: "Completada", done: true },
      {
        title: "Losartán · 50 mg",
        detail: "09:00 · Después del desayuno",
        meta: "Completada",
        done: true,
      },
      { title: "Comida", detail: "12:30 · Dieta baja en sodio", meta: "En curso" },
      { title: "Caminata suave", detail: "16:00 · 15 minutos", meta: "Pendiente" },
    ],
    action: "Nueva tarea",
  },
  caregivers: {
    title: "Usuarios y accesos",
    subtitle: "FAMILIA Y CUIDADORES",
    icon: "users",
    intro: "2 administradores · 2 usuarios secundarios",
    items: [
      {
        title: "Ana Martínez",
        detail: "Cuidadora principal · Administradora",
        meta: "Acceso total",
        done: true,
      },
      {
        title: "Luis Ramírez",
        detail: "Hijo · Administrador",
        meta: "Vive lejos · apoyo económico",
        done: true,
      },
      {
        title: "María López",
        detail: "Enfermera · Secundaria",
        meta: "Bitácora, tareas y alertas",
      },
    ],
    action: "Agregar nuevo cuidador",
  },
  "patient-create": {
    title: "Pacientes",
    subtitle: "PERFILES ASIGNADOS",
    icon: "users",
    intro: "3 pacientes activos",
    items: [
      {
        title: "José Ramírez",
        detail: "78 años · Don José · Melocotón",
        meta: "Hipertensión · Diabetes tipo 2",
        done: true,
      },
      {
        title: "Elena Torres",
        detail: "82 años · Doña Elena · Salvia",
        meta: "Artritis · Osteoporosis",
        done: true,
      },
      {
        title: "Roberto Díaz",
        detail: "74 años · Don Roberto · Amarillo suave",
        meta: "Hipertensión · Alergia a sulfas",
        done: true,
      },
    ],
    action: "Agregar nuevo",
  },
};

function UtilityScreen({
  kind,
  back,
  navigate,
  notify,
}: {
  kind: UtilityKind;
  back: () => void;
  navigate: (screen: Screen) => void;
  notify: (message: string) => void;
}) {
  const content = utilityContent[kind];
  const [items, setItems] = useState(() => content.items.map((item) => ({ ...item })));
  const [completed, setCompleted] = useState<number[]>(
    content.items.map((item, index) => (item.done ? index : -1)).filter((index) => index >= 0),
  );
  const toggle = (index: number) =>
    setCompleted((current) =>
      current.includes(index) ? current.filter((item) => item !== index) : [...current, index],
    );
  const [actionOpen, setActionOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [formName, setFormName] = useState("");
  const [selectedChoice, setSelectedChoice] = useState("");
  const [formDate, setFormDate] = useState("2026-11-24");
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [age, setAge] = useState("");
  const [conditions, setConditions] = useState("");
  const [allergies, setAllergies] = useState("");
  const [medicalDirections, setMedicalDirections] = useState("");
  const [medicationName, setMedicationName] = useState("");
  const [dose, setDose] = useState("");
  const [medicationTime, setMedicationTime] = useState("09:00");
  const [medicationDirections, setMedicationDirections] = useState("");
  const [emergencyContact, setEmergencyContact] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [doctorPhone, setDoctorPhone] = useState("");
  const isStepper = kind === "caregivers" || kind === "patient-create";
  const maxSteps = kind === "patient-create" ? 4 : kind === "caregivers" ? 3 : 1;

  return (
    <div className="screen">
      <TopBar
        title={content.title}
        subtitle={content.subtitle}
        back={back}
        points={false}
        onProfile={() => navigate("admin")}
      />
      <main className="content utility-content">
        <section className="utility-intro">
          <span>
            <Icon name={content.icon} />
          </span>
          <div>
            <h1>{content.intro}</h1>
            <p>Información coordinada para cuidar mejor.</p>
          </div>
        </section>
        <div className="utility-list">
          {items.map((item, index) => (
            <div className="utility-row" key={item.title}>
              <button
                className={`utility-check ${completed.includes(index) ? "done" : ""}`}
                aria-label={completed.includes(index) ? "Desmarcar" : "Marcar"}
                onClick={() => toggle(index)}
              >
                <Icon name="check" size={17} />
              </button>
              <span>
                <strong>{item.title}</strong>
                <small>{item.detail}</small>
                <em>{completed.includes(index) ? "Listo" : item.meta}</em>
              </span>
              <button
                className="utility-edit"
                aria-label={`Editar ${item.title}`}
                onClick={() => {
                  setEditingIndex(index);
                  setFormName(item.title);
                  if (kind === "medications") {
                    const [currentName, currentDose = ""] = item.title.split(" · ");
                    setMedicationName(currentName);
                    setDose(currentDose);
                    setMedicationTime(item.detail.split(" · ")[0] || "09:00");
                    setMedicationDirections(item.meta);
                  }
                  setStep(1);
                  setActionOpen(true);
                }}
              >
                <Icon name="edit" size={18} />
              </button>
            </div>
          ))}
        </div>
        <Button
          icon={kind === "patient-create" ? "chevron" : "plus"}
          onClick={() => {
            setEditingIndex(null);
            setFormName("");
            setMedicationName("");
            setDose("");
            setMedicationTime("09:00");
            setMedicationDirections("");
            setActionOpen(true);
          }}
        >
          {content.action}
        </Button>
      </main>
      {actionOpen && (
        <ActionSheet
          title={editingIndex === null ? content.action : `Editar ${items[editingIndex].title}`}
          subtitle={isStepper ? `PASO ${step} DE ${maxSteps}` : "NUEVO REGISTRO"}
          close={() => {
            setActionOpen(false);
            setStep(1);
            setEditingIndex(null);
          }}
        >
          <div className="sheet-form">
            {step === 1 && (
              <>
                {kind === "medications" ? (
                  <>
                    <FormField
                      label="Nombre del medicamento"
                      value={medicationName}
                      onChange={setMedicationName}
                      placeholder="Ej. Metformina"
                    />
                    <FormField
                      label="Dosis"
                      value={dose}
                      onChange={setDose}
                      placeholder="Ej. 850 mg"
                    />
                    <FormField
                      label="Horario"
                      type="time"
                      value={medicationTime}
                      onChange={setMedicationTime}
                    />
                    <FormField
                      label="Indicaciones"
                      value={medicationDirections}
                      onChange={setMedicationDirections}
                      placeholder="Ej. Después de comer"
                    />
                  </>
                ) : (
                  <>
                    <FormField
                      label={
                        kind === "caregivers"
                          ? "Nombre del cuidador"
                          : kind === "patient-create"
                            ? "Nombre del paciente"
                            : "Nombre"
                      }
                      value={formName}
                      onChange={setFormName}
                      placeholder="Escribe un nombre"
                    />
                    {kind === "patient-create" ? (
                      <FormField
                        label="Edad"
                        type="number"
                        value={age}
                        onChange={setAge}
                        placeholder="Ej. 78"
                      />
                    ) : (
                      <FormField
                        label={kind === "appointments" ? "Fecha de la cita" : "Fecha"}
                        type="date"
                        value={formDate}
                        onChange={setFormDate}
                      />
                    )}
                  </>
                )}
              </>
            )}
            {step === 2 && (
              <>
                {kind === "patient-create" ? (
                  <>
                    <div className="step-explanation">
                      <strong>Salud y cuidados</strong>
                      <p>
                        Registra información que el cuidador debe conocer antes de atender al
                        paciente.
                      </p>
                    </div>
                    <FormField
                      label="Condiciones"
                      value={conditions}
                      onChange={setConditions}
                      placeholder="Ej. Hipertensión, diabetes"
                    />
                    <FormField
                      label="Alergias"
                      value={allergies}
                      onChange={setAllergies}
                      placeholder="Ej. Penicilina o ninguna conocida"
                    />
                    <FormField
                      label="Indicaciones médicas"
                      value={medicalDirections}
                      onChange={setMedicalDirections}
                      placeholder="Ej. Dieta baja en sodio"
                    />
                  </>
                ) : (
                  <div className="choice-grid">
                    {["Administrador", "Secundario"].map((choice) => (
                      <button
                        className={selectedChoice === choice ? "selected" : ""}
                        key={choice}
                        onClick={() => setSelectedChoice(choice)}
                      >
                        {choice}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
            {step === 3 && kind === "patient-create" && (
              <>
                <div className="step-explanation">
                  <strong>Medicamentos y horarios</strong>
                  <p>
                    Agrega la primera toma. Después podrás registrar más medicamentos desde su
                    perfil.
                  </p>
                </div>
                <FormField
                  label="Medicamento"
                  value={medicationName}
                  onChange={setMedicationName}
                  placeholder="Ej. Losartán"
                />
                <FormField label="Dosis" value={dose} onChange={setDose} placeholder="Ej. 50 mg" />
                <FormField
                  label="Hora"
                  type="time"
                  value={medicationTime}
                  onChange={setMedicationTime}
                />
                <FormField
                  label="Indicaciones de la toma"
                  value={medicationDirections}
                  onChange={setMedicationDirections}
                  placeholder="Ej. Después del desayuno"
                />
              </>
            )}
            {step === 3 && kind === "caregivers" && (
              <>
                <div className="step-explanation">
                  <strong>Permisos del cuidador</strong>
                  <p>Define qué información puede consultar y qué avisos recibirá.</p>
                </div>
                <label className="toggle-row">
                  <span>
                    <strong>Ver bitácora</strong>
                    <small>Puede consultar los registros diarios del paciente</small>
                  </span>
                  <input type="checkbox" defaultChecked />
                </label>
                <label className="toggle-row">
                  <span>
                    <strong>Recibir alertas</strong>
                    <small>Avisos importantes</small>
                  </span>
                  <input type="checkbox" defaultChecked />
                </label>
                <label className="toggle-row">
                  <span>
                    <strong>Vive lejos</strong>
                    <small>Solo apoyo económico</small>
                  </span>
                  <input type="checkbox" />
                </label>
              </>
            )}
            {step === 4 && kind === "patient-create" && (
              <>
                <div className="step-explanation">
                  <strong>Contactos médicos y de emergencia</strong>
                  <p>Estos datos aparecerán como accesos rápidos durante una emergencia.</p>
                </div>
                <FormField
                  label="Contacto de emergencia"
                  value={emergencyContact}
                  onChange={setEmergencyContact}
                  placeholder="Nombre y teléfono"
                />
                <FormField
                  label="Médico de cabecera"
                  value={doctorName}
                  onChange={setDoctorName}
                  placeholder="Nombre del médico"
                />
                <FormField
                  label="Teléfono del médico"
                  type="tel"
                  value={doctorPhone}
                  onChange={setDoctorPhone}
                  placeholder="55 0000 0000"
                />
              </>
            )}
            <div className="step-actions">
              {step > 1 && (
                <Button
                  className="back-step"
                  variant="secondary"
                  icon="chevron"
                  onClick={() => setStep((current) => current - 1)}
                >
                  Anterior
                </Button>
              )}
              <Button
                icon={step < maxSteps ? "chevron" : "check"}
                onClick={() => {
                  if (step < maxSteps) {
                    setStep((current) => current + 1);
                    return;
                  }
                  const name = kind === "medications" ? medicationName.trim() : formName.trim();
                  if (!name) {
                    notify(
                      kind === "medications"
                        ? "Escribe el nombre del medicamento"
                        : "Escribe un nombre antes de guardar",
                    );
                    return;
                  }
                  const newItem =
                    kind === "medications"
                      ? {
                          title: `${medicationName.trim()}${dose.trim() ? ` · ${dose.trim()}` : ""}`,
                          detail: `${medicationTime} · ${medicationDirections || "Sin indicaciones adicionales"}`,
                          meta: "Programado",
                        }
                      : kind === "patient-create"
                        ? {
                            title: formName.trim(),
                            detail: `${age || "Edad no indicada"} años · ${
                              medicationName
                                ? `${medicationName}${dose ? ` ${dose}` : ""} a las ${medicationTime}`
                                : "Sin medicamentos registrados"
                            }`,
                            meta:
                              [conditions, allergies && `Alergia: ${allergies}`, medicalDirections]
                                .filter(Boolean)
                                .join(" · ") || "Información médica por completar",
                          }
                        : {
                            title: formName.trim(),
                            detail: formDate,
                            meta: "Nuevo registro",
                          };
                  if (editingIndex === null) {
                    setItems((current) => [...current, newItem]);
                  } else {
                    setItems((current) =>
                      current.map((item, index) =>
                        index === editingIndex ? { ...item, ...newItem } : item,
                      ),
                    );
                  }
                  setActionOpen(false);
                  setStep(1);
                  setFormName("");
                  setSelectedChoice("");
                  setEditingIndex(null);
                  notify(
                    kind === "medications"
                      ? "Medicamento guardado y agregado al horario"
                      : `${content.action}: información guardada`,
                  );
                }}
              >
                {step < maxSteps ? "Continuar" : "Guardar"}
              </Button>
            </div>
          </div>
        </ActionSheet>
      )}
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [selectedPatient, setSelectedPatient] = useState<PatientId>("jose");
  const [history, setHistory] = useState<Screen[]>([]);
  const [toast, setToast] = useState("");
  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  };
  const navigate = (next: Screen) => {
    if (next === screen) return;
    setHistory((current) => [...current, screen]);
    setScreen(next);
    document.querySelector(".app-shell")?.scrollTo({ top: 0, behavior: "smooth" });
  };
  const goBack = () => {
    const previous = history.at(-1) ?? "home";
    setHistory((current) => current.slice(0, -1));
    setScreen(previous);
    document.querySelector(".app-shell")?.scrollTo({ top: 0, behavior: "smooth" });
  };
  const render = () => {
    if (screen === "home")
      return (
        <Home
          navigate={navigate}
          notify={notify}
          patient={selectedPatient}
          selectPatient={setSelectedPatient}
        />
      );
    if (screen === "admin") return <Admin back={goBack} navigate={navigate} notify={notify} />;
    if (screen === "log") return <Logbook navigate={navigate} notify={notify} />;
    if (screen === "needs")
      return <Logbook initialSegment="needs" navigate={navigate} notify={notify} />;
    if (screen === "notes") return <Notes navigate={navigate} notify={notify} />;
    if (screen === "points") return <Points navigate={navigate} notify={notify} />;
    if (screen === "profile")
      return (
        <Profile back={goBack} navigate={navigate} notify={notify} patient={selectedPatient} />
      );
    if (screen === "family") return <Family back={goBack} navigate={navigate} />;
    if (screen === "emergency") return <Emergency back={goBack} notify={notify} />;
    return <UtilityScreen kind={screen} back={goBack} navigate={navigate} notify={notify} />;
  };
  const showNav = ["home", "log", "needs", "notes", "points"].includes(screen);
  const activeTab = screen === "needs" ? "log" : screen;
  return (
    <div className="stage">
      <div className="app-shell">
        {render()}
        {showNav && <BottomNav active={activeTab} navigate={navigate} />}
        {toast && (
          <div className="toast">
            <Icon name="check" size={18} />
            <span>{toast}</span>
          </div>
        )}
      </div>
    </div>
  );
}
